import cv2

def capture_image(frame):
    # Save the captured frame as an image
    cv2.imwrite("captured_image.jpg", frame)
    print("Image captured and saved as captured_image.jpg")

# Open the camera
camera = cv2.VideoCapture(0)

# Check if the camera is opened successfully
if not camera.isOpened():
    print("Failed to open the camera")
else:
    while True:
        # Read a frame from the camera
        ret, frame = camera.read()

        # Check if the frame was successfully read
        if not ret:
            print("Failed to capture frame")
            break

        # Display the camera feed
        cv2.imshow("Camera Feed", frame)

        # Wait for a key press
        key = cv2.waitKey(1) & 0xFF

        # If the 'C' key is pressed, capture and save the image
        if key == ord('C') or key == ord('c'):
            capture_image(frame)

        # If the 'Esc' key is pressed, exit the program
        if key == 27:
            break

# Release the camera and close any open windows
camera.release()
cv2.destroyAllWindows()
