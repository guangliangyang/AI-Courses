from PIL import Image, ImageDraw

# Create a blank white image with a width of 160 pixels and height of 10 pixels
image = Image.new("RGB", (160, 10), "white")

# Draw a red line from (0, 5) to (159, 5)
draw = ImageDraw.Draw(image)
draw.line((0, 5, 159, 5), fill="red", width=2)

# Save the image
image.save("shot.png")

# Show the image (requires external viewer, e.g., default image viewer on your system)
image.show()
