import cv2

# Load the image or frame containing the chessboard
image = cv2.imread('1111.png', cv2.IMREAD_GRAYSCALE)  # Replace 'chessboard.jpg' with your image path

# Define the dimensions of the chessboard
num_corners_x = 11  # Number of corners along the x-axis of the chessboard (num_corners_x = square-1)
num_corners_y = 7  # Number of corners along the y-axis of the chessboard (num_corners_y = square-1)

# Find chessboard corners in the image
success, corners = cv2.findChessboardCorners(image, (num_corners_x, num_corners_y))

if success:
    # Calculate the distance between two adjacent corners
    corner_1 = corners[0, 0]  # First corner
    corner_2 = corners[1, 0]  # Second corner
    size_in_pixels = corner_2[0] - corner_1[0]  # Distance in pixels

    print("Size in pixels:", size_in_pixels)
else:
    print("Chessboard corners not found in the image.")
