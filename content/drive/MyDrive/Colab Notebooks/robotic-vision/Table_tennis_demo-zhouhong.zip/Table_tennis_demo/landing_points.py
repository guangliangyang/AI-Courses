import cv2
import numpy as np

def divide_distance_into_parts(vertex1, vertex2, num_parts):
    x1, y1 = vertex1
    x2, y2 = vertex2
    distance = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    if distance < 100:  # Adjust the threshold for shorter distances
        num_parts = 3
    parts = []
    for i in range(1, num_parts):
        x = int(x1 + (x2 - x1) * i / num_parts)
        y = int(y1 + (y2 - y1) * i / num_parts)
        parts.append((x, y))
    return parts


def find_tennis_table_edges(image_path):
    # Load the image
    image = cv2.imread(image_path)

    # Convert image to HSV color space
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    # Define color range for the tennis table (adjust values as needed)
    lower_color = np.array([90, 50, 50]) #90, 50, 50
    upper_color = np.array([130, 255, 255]) #130, 255, 255

    # Threshold the image to get the tennis table mask
    mask = cv2.inRange(hsv, lower_color, upper_color)

    # Apply morphological operations to clean up the mask
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    # Find contours in the mask
    contours, _ = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Filter and draw the largest tennis table contour
    table_contour = max(contours, key=cv2.contourArea)
    cv2.drawContours(image, [table_contour], -1, (0, 255, 0), 2)

    # Find the convex hull of the tennis table contour
    hull = cv2.convexHull(table_contour)

    # Approximate the polygonal curve to find the vertices
    epsilon = 0.04 * cv2.arcLength(hull, True)
    approx = cv2.approxPolyDP(hull, epsilon, True)

    # Create a list to store the print results
    print_results = []

    vertex_labels = ['A', 'B', 'C', 'D']
    for i, vertex in enumerate(approx):
        x, y = vertex[0]
        cv2.circle(image, (x, y), 5, (0, 0, 255), -1)
        label = vertex_labels[i]
        cv2.putText(image, label, (x + 10, y + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
        print(f"{label}: ({x}, {y})")
        # Append the name and coordinates of the vertices to the print results
        print_results.append(f"{label}: ({x}, {y})")

    # Divide the distance between each pair of vertices into parts
    labeled_points = []
    point_counters = {'A': 1, 'B': 1, 'C': 1, 'D': 1}  # Counter for each vertex label
    for i in range(len(approx)):
        vertex1 = approx[i][0]
        vertex2 = approx[(i + 1) % len(approx)][0]
        num_parts = 6 if i in [0, 2] else 3  # Divide into 6 parts for longer distances, 3 parts for shorter distances
        parts = divide_distance_into_parts(vertex1, vertex2, num_parts)
        for part in parts:
            x, y = part
            cv2.circle(image, (x, y), 3, (255, 0, 0), -1)

            vertex_label = vertex_labels[i]
            point_label = f'{vertex_label}{point_counters[vertex_label]}'  # e.g., A1, A2, A3, B1, B2, C1, C2, ...
            labeled_points.append((x, y, point_label))
            point_counters[vertex_label] += 1

            # Print the name and coordinates of the point
            print(f"{point_label}: ({x}, {y})")
            # Append the name and coordinates of the point to the print results
            print_results.append(f"{point_label}: ({x}, {y})")

        # Label the points and indicate the side they belong to
        for point in labeled_points:
            x, y, point_label = point
            cv2.putText(image, point_label, (x + 10, y + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

            # Connect specific points
            if point_label == 'A1':
                try:
                    point_to_connect = next(p for p in labeled_points if p[2] == 'C5')
                    x2, y2, _ = point_to_connect
                    cv2.line(image, (x, y), (x2, y2), (0, 255, 0), 2)

                    # Calculate the two points that divide the line
                    num_parts = 3
                    parts = divide_distance_into_parts((x, y), (x2, y2), num_parts)
                    x1, y1 = parts[0]
                    x3, y3 = parts[1]

                    # Draw the two points on the image and label them
                    cv2.circle(image, (x1, y1), 3, (0, 0, 255), -1)
                    cv2.circle(image, (x3, y3), 3, (0, 0, 255), -1)
                    cv2.putText(image, "A1C5_1", (x1 + 10, y1 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                    cv2.putText(image, "A1C5_2", (x3 + 10, y3 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

                    # Print the coordinates of 'A1C5_1'
                    print("A1C5_1:", (x1, y1))
                    # Print the coordinates of 'A1C5_2'
                    print("A1C5_2:", (x3, y3))
                    # Append the coordinates of 'A5C1_1' and 'A5C1_2' to the print results
                    print_results.append(f"A1C5_1: ({x1}, {y1})")
                    print_results.append(f"A1C5_2: ({x3}, {y3})")

                except StopIteration:
                    pass
            elif point_label == 'A2':
                try:
                    point_to_connect = next(p for p in labeled_points if p[2] == 'C4')
                    x2, y2, _ = point_to_connect
                    cv2.line(image, (x, y), (x2, y2), (0, 255, 0), 2)

                    # Calculate the two points that divide the line
                    num_parts = 3
                    parts = divide_distance_into_parts((x, y), (x2, y2), num_parts)
                    x1, y1 = parts[0]
                    x3, y3 = parts[1]

                    # Draw the two points on the image and label them
                    cv2.circle(image, (x1, y1), 3, (0, 0, 255), -1)
                    cv2.circle(image, (x3, y3), 3, (0, 0, 255), -1)
                    cv2.putText(image, "A2C4_1", (x1 + 10, y1 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                    cv2.putText(image, "A2C4_2", (x3 + 10, y3 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

                    # Print the coordinates of 'A1C5_1'
                    print("A2C4_1:", (x1, y1))
                    # Print the coordinates of 'A1C5_2'
                    print("A2C4_2:", (x3, y3))
                    # Append the coordinates of 'A2C4_1' and 'A2C4_2' to the print results
                    print_results.append(f"A2C4_1: ({x1}, {y1})")
                    print_results.append(f"A2C4_2: ({x3}, {y3})")
                except StopIteration:
                    pass
            # Connect specific points
            if point_label == 'A3':
                try:
                    point_to_connect = next(p for p in labeled_points if p[2] == 'C3')
                    x2, y2, _ = point_to_connect
                    #cv2.line(image, (x, y), (x2, y2), (0, 255, 0), 2)

                    # Calculate the two points that divide the line
                    num_parts = 3
                    parts = divide_distance_into_parts((x, y), (x2, y2), num_parts)
                    x1, y1 = parts[0]
                    x3, y3 = parts[1]

                    # Draw the two points on the image and label them
                    cv2.circle(image, (x1, y1), 3, (0, 0, 255), -1)
                    cv2.circle(image, (x3, y3), 3, (0, 0, 255), -1)
                    cv2.putText(image, "A3C3_1", (x1 + 10, y1 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255),
                                        2)
                    cv2.putText(image, "A3C3_2", (x3 + 10, y3 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255),
                                        2)

                    # Print the coordinates of 'A1C5_1'
                    print("A3C3_1:", (x1, y1))
                    # Print the coordinates of 'A1C5_2'
                    print("A3C3_2:", (x3, y3))
                    # Append the coordinates of 'A3C3_1' and 'A3C3_2' to the print results
                    print_results.append(f"A3C3_1: ({x1}, {y1})")
                    print_results.append(f"A3C3_2: ({x3}, {y3})")
                except StopIteration:
                    pass
            elif point_label == 'A4':
                try:
                    point_to_connect = next(p for p in labeled_points if p[2] == 'C2')
                    x2, y2, _ = point_to_connect
                    cv2.line(image, (x, y), (x2, y2), (0, 255, 0), 2)

                    # Calculate the two points that divide the line
                    num_parts = 3
                    parts = divide_distance_into_parts((x, y), (x2, y2), num_parts)
                    x1, y1 = parts[0]
                    x3, y3 = parts[1]

                    # Draw the two points on the image and label them
                    cv2.circle(image, (x1, y1), 3, (0, 0, 255), -1)
                    cv2.circle(image, (x3, y3), 3, (0, 0, 255), -1)
                    cv2.putText(image, "A4C2_1", (x1 + 10, y1 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                    cv2.putText(image, "A4C2_2", (x3 + 10, y3 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

                    # Print the coordinates of 'A1C5_1'
                    print("A4C2_1:", (x1, y1))
                    # Print the coordinates of 'A1C5_2'
                    print("A4C2_2:", (x3, y3))

                    # Append the coordinates of 'A4C2_1' and 'A4C2_2' to the print results
                    print_results.append(f"A4C2_1: ({x1}, {y1})")
                    print_results.append(f"A4C2_2: ({x3}, {y3})")

                except StopIteration:
                    pass
            elif point_label == 'A5':
                try:
                    point_to_connect = next(p for p in labeled_points if p[2] == 'C1')
                    x2, y2, _ = point_to_connect
                    cv2.line(image, (x, y), (x2, y2), (0, 255, 0), 2)

                    # Calculate the two points that divide the line
                    num_parts = 3
                    parts = divide_distance_into_parts((x, y), (x2, y2), num_parts)
                    x1, y1 = parts[0]
                    x3, y3 = parts[1]

                    # Draw the two points on the image and label them
                    cv2.circle(image, (x1, y1), 3, (0, 0, 255), -1)
                    cv2.circle(image, (x3, y3), 3, (0, 0, 255), -1)
                    cv2.putText(image, "A5C1_1", (x1 + 10, y1 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                    cv2.putText(image, "A5C1_2", (x3 + 10, y3 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

                    # Print the coordinates of 'A1C5_1'
                    print("A5C1_1:", (x1, y1))
                    # Print the coordinates of 'A1C5_2'
                    print("A5C1_2:", (x3, y3))

                    # Append the coordinates of 'A5C1_1' and 'A5C1_2' to the print results
                    print_results.append(f"A5C1_1: ({x1}, {y1})")
                    print_results.append(f"A5C1_2: ({x3}, {y3})")
                except StopIteration:
                    pass
            elif point_label == 'B1':
                try:
                    point_to_connect = next(p for p in labeled_points if p[2] == 'D2')
                    x2, y2, _ = point_to_connect
                    cv2.line(image, (x, y), (x2, y2), (0, 255, 0), 2)
                except StopIteration:
                    pass
            elif point_label == 'B2':
                try:
                    point_to_connect = next(p for p in labeled_points if p[2] == 'D1')
                    x2, y2, _ = point_to_connect
                    cv2.line(image, (x, y), (x2, y2), (0, 255, 0), 2)
                except StopIteration:
                    pass

    # Save the print results into a file without duplicates
    with open('Region_division.txt', 'w') as file:
        unique_results = set(print_results)
        file.write('\n'.join(unique_results))

    # Display the image with detected table and divided distances
    cv2.imshow('Tennis Table Detection', image)
    cv2.imshow('mask', mask)
    #cv2.imshow('mask', mask)
    cv2.waitKey(0)
    cv2.destroyAllWindows()



# Provide the path to your image
image_path = 'captured_image.jpg'
find_tennis_table_edges(image_path)
